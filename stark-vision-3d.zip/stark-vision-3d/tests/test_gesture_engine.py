"""Testes unitários para o motor de gestos espaciais (Pinça 1 Mão e Zoom 2 Mãos)."""

from main import build_synthetic_hand
from src.vision.gesture_engine import GestureEngine, GestureState


def test_single_hand_pinch_rotates_3_axes():
    """Pinça com 1 mão na zona orbital deve entrar em SINGLE_ROTATE_3D e alterar Pitch, Yaw e Roll."""
    w, h = 1280, 720
    engine = GestureEngine(frame_width=w, frame_height=h, auto_idle_spin=False)
    init_rot = engine.smooth_transform.rotation_rad.copy()

    # Frame 1: Mão direita inicia pinça fora do núcleo central (x=0.72, y=0.45)
    h1 = build_synthetic_hand(0.72, 0.45, pinch_openness=0.05, wrist_roll_rad=0.0, frame_w=w, frame_h=h)
    _, tel1 = engine.update([h1])
    assert tel1.state == GestureState.SINGLE_ROTATE_3D

    # Frame 2: Move a mão para (x=0.82, y=0.35) e gira o pulso (+0.4 rad)
    h2 = build_synthetic_hand(0.82, 0.35, pinch_openness=0.05, wrist_roll_rad=0.4, frame_w=w, frame_h=h)
    transform2, tel2 = engine.update([h2])
    assert tel2.state == GestureState.SINGLE_ROTATE_3D

    # Verifica que os 3 eixos de rotação (Pitch, Yaw, Roll) responderam ao movimento
    assert transform2.rotation_rad[0] != init_rot[0]  # Pitch (dy)
    assert transform2.rotation_rad[1] != init_rot[1]  # Yaw (dx)
    assert transform2.rotation_rad[2] != init_rot[2]  # Roll (pulso)


def test_single_hand_pinch_on_core_moves_hologram():
    """Pinça com 1 mão sobre o núcleo central (0.5, 0.5) deve agarrar e mover a posição (X, Y)."""
    w, h = 1280, 720
    engine = GestureEngine(frame_width=w, frame_height=h, auto_idle_spin=False)
    init_pos = engine.smooth_transform.position_px.copy()

    # Frame 1: Pinça exatamente no centro (0.50, 0.50)
    h1 = build_synthetic_hand(0.50, 0.50, pinch_openness=0.05, wrist_roll_rad=0.0, frame_w=w, frame_h=h)
    _, tel1 = engine.update([h1])
    assert tel1.state == GestureState.SINGLE_MOVE_3D

    # Frame 2: Arrasta a mão para a direita e para baixo
    h2 = build_synthetic_hand(0.62, 0.58, pinch_openness=0.05, wrist_roll_rad=0.0, frame_w=w, frame_h=h)
    transform2, _ = engine.update([h2])
    assert transform2.position_px[0] > init_pos[0]
    assert transform2.position_px[1] > init_pos[1]


def test_dual_hand_pinch_scales_hologram():
    """Pinça simultânea com as 2 mãos deve ativar DUAL_ZOOM_SCALE e ampliar a escala ao afastar as mãos."""
    w, h = 1280, 720
    engine = GestureEngine(frame_width=w, frame_height=h, auto_idle_spin=False)

    # Frame 1: Duas mãos em pinça próximas uma da outra (x=0.40 e x=0.60)
    left_1 = build_synthetic_hand(0.40, 0.50, pinch_openness=0.05, wrist_roll_rad=0.0, frame_w=w, frame_h=h, label="Left")
    right_1 = build_synthetic_hand(0.60, 0.50, pinch_openness=0.05, wrist_roll_rad=0.0, frame_w=w, frame_h=h, label="Right")
    t1, tel1 = engine.update([left_1, right_1])
    assert tel1.state == GestureState.DUAL_ZOOM_SCALE

    # Frame 2: Afastando as duas mãos em pinça (x=0.25 e x=0.75) -> Deve aumentar o zoom (> 1.0)
    left_2 = build_synthetic_hand(0.25, 0.50, pinch_openness=0.05, wrist_roll_rad=0.0, frame_w=w, frame_h=h, label="Left")
    right_2 = build_synthetic_hand(0.75, 0.50, pinch_openness=0.05, wrist_roll_rad=0.0, frame_w=w, frame_h=h, label="Right")
    t2, tel2 = engine.update([left_2, right_2])
    assert tel2.state == GestureState.DUAL_ZOOM_SCALE
    assert t2.scale > t1.scale
