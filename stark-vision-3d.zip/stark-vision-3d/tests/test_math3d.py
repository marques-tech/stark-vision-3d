"""Testes unitários para o motor matemático 3D (Matrizes de Rotação e Projeção Perspectiva)."""

import math
import numpy as np

from src.engine3d.math3d import (
    compute_faces_lighting_and_order,
    rotation_matrix_euler,
    transform_and_project_vertices,
)


def test_rotation_matrix_orthogonality():
    """Toda matriz de rotação 3D deve ser ortogonal (R @ R.T == I e det(R) == +1)."""
    rot = rotation_matrix_euler(0.4, -0.7, 1.1)
    identity = rot @ rot.T
    assert np.allclose(identity, np.eye(3), atol=1e-10)
    assert math.isclose(float(np.linalg.det(rot)), 1.0, rel_tol=1e-9)


def test_perspective_projection_center():
    """Um vértice na origem (0, 0, 0) deve projetar exatamente no centro (cx, cy) da tela."""
    verts = np.array([[0.0, 0.0, 0.0], [0.5, 0.0, 0.0]], dtype=np.float64)
    center = np.array([640.0, 360.0], dtype=np.float64)
    rot = np.array([0.0, 0.0, 0.0], dtype=np.float64)

    pts_2d, _ = transform_and_project_vertices(
        vertices=verts,
        rotation_rad=rot,
        scale=1.0,
        center_xy=center,
    )
    assert np.allclose(pts_2d[0], center, atol=1e-6)
    # O segundo vértice tem X > 0, logo deve projetar à direita do centro
    assert pts_2d[1, 0] > center[0]
    assert math.isclose(float(pts_2d[1, 1]), float(center[1]), abs_tol=1e-6)


def test_z_sorting_painters_algorithm():
    """Faces mais distantes (menor Z) devem vir primeiro na ordenação do Algoritmo do Pintor."""
    verts = np.array([
        [0.0, 0.0,  0.8], [1.0, 0.0,  0.8], [0.0, 1.0,  0.8],  # Face 0: Perto (Z = +0.8)
        [0.0, 0.0, -0.8], [1.0, 0.0, -0.8], [0.0, 1.0, -0.8],  # Face 1: Longe (Z = -0.8)
    ], dtype=np.float64)
    faces = np.array([[0, 1, 2], [3, 4, 5]], dtype=np.int32)

    sorted_idx, intensities, normals = compute_faces_lighting_and_order(verts, faces)
    assert list(sorted_idx) == [1, 0]
    assert len(intensities) == 2
    assert normals.shape == (2, 3)
