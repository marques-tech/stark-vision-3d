"""Testes unitários para o carregador de malhas 3D (.OBJ) e gerador de IA 3D na CPU."""

from pathlib import Path
import numpy as np

from src.ai.generator_3d import AI3DGenerator
from src.ai.procedural_meshes import ensure_default_models
from src.engine3d.mesh_loader import load_mesh_file


def test_default_stark_models_generation_and_loading(tmp_path: Path):
    """Os 3 modelos padrão (Arc Reactor, Jarvis Core, Stark Drone) devem ser gerados e carregados."""
    paths = ensure_default_models(tmp_path)
    assert len(paths) == 3

    for p in paths:
        assert p.exists()
        mesh = load_mesh_file(p, max_faces=1800)
        assert mesh.num_vertices > 10
        assert mesh.num_faces > 10
        assert mesh.num_edges > 10
        # Verifica normalização na esfera unitária
        radii = np.linalg.norm(mesh.vertices, axis=1)
        assert np.max(radii) <= 1.0001


def test_ai_text_to_3d_cpu_synthesizer(tmp_path: Path):
    """O gerador Text-to-3D local deve sintetizar uma malha 3D válida a partir de qualquer prompt."""
    gen = AI3DGenerator(output_dir=tmp_path, max_faces_cpu=1200)
    mesh, saved_path, backend = gen.text_to_3d("quantum cyberpunk crystal", use_cloud_api=False)
    assert saved_path.exists()
    assert mesh.num_vertices > 20
    assert mesh.num_faces <= 1200
    assert "CPU" in backend


def test_ai_image_to_3d_relief_cpu(tmp_path: Path):
    """O conversor Image-to-3D deve transformar uma imagem 2D em uma malha volumétrica 3D."""
    # Cria uma imagem sintética 128x128 com um círculo brilhante no centro
    synthetic_img = np.zeros((128, 128, 3), dtype=np.uint8)
    synthetic_img[32:96, 32:96] = (255, 220, 120)

    gen = AI3DGenerator(output_dir=tmp_path, max_faces_cpu=1500)
    mesh, saved_path = gen.image_to_3d_relief_cpu(synthetic_img, name="test_relief", grid_size=20)
    assert saved_path.exists()
    assert mesh.num_vertices == 20 * 20 * 2
    assert mesh.num_faces > 100
