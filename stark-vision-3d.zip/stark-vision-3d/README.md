# Stark Vision 3D — J.A.R.V.I.S. Holographic Hand Interface

> **Visão Computacional + Renderização 3D Vetorial + IA Generativa 3D em Python (100% Otimizado para CPU a 30–60+ FPS)**

Um sistema de Realidade Aumentada inspirado na interface holográfica do **Tony Stark (J.A.R.V.I.S.)**. Utiliza **MediaPipe Hands** e **OpenCV/NumPy** para rastrear os 21 marcos anatômicos das mãos em tempo real através de uma webcam comum e manipular modelos 3D gerados por Inteligência Artificial (ou arquivos `.obj`, `.glb`, `.stl`) diretamente no espaço 3D sobre o vídeo.

---

## Destaques do Projeto (Para Estudos e Portfólio)

1. **Invariância à Profundidade na Detecção de Pinça (`Pinch Ratio`)**:
   - Projetos básicos medem apenas a distância em pixels entre a ponta do polegar (Landmark `4`) e do indicador (Landmark `8`), o que falha quando a mão se afasta ou se aproxima da câmera.
   - Aqui calculamos a razão normalizada pelo tamanho aparente da palma (distância entre o pulso `0` e a base do dedo médio `9`), combinada com **histerese de estado** (`pinch_start_ratio = 0.34`, `pinch_release_ratio = 0.44`):
     $$\text{PinchRatio} = \frac{\|\mathbf{p}_4 - \mathbf{p}_8\|_2}{\|\mathbf{p}_0 - \mathbf{p}_9\|_2}$$

2. **Manipulação Espacial com 1 e 2 Mãos**:
   - **Pinça com 1 Mão (Rotação 3 Eixos + Translação)**:
     - **Anel Orbital**: Deslocar a mão em pinça controla **Yaw** ($\theta_y$) e **Pitch** ($\theta_x$), enquanto inclinar o pulso gira o eixo **Roll** ($\theta_z$) em tempo real.
     - **Núcleo Central**: Pinçar diretamente sobre o centro do holograma agarra e move o objeto 3D pelas coordenadas $(X, Y)$ da tela.
   - **Pinça Dupla Simultânea (Zoom / Escala com as 2 Mãos)**:
     - Quando ambas as mãos entram em pinça simultaneamente, o sistema traça um feixe de tensão entre elas e calcula a escala proporcional:
       $$S(t) = S_0 \cdot \frac{\|\mathbf{c}_{\text{dir}}(t) - \mathbf{c}_{\text{esq}}(t)\|_2}{d_0}$$

3. **Filtro Temporal Anti-Tremor (EMA - Exponential Moving Average)**:
   - Elimina o ruído de alta frequência (*jitter*) típico de webcams através de filtragem recursiva passa-baixa:
     $$\hat{\mathbf{y}}_t = \alpha \mathbf{x}_t + (1 - \alpha)\hat{\mathbf{y}}_{t-1}$$

4. **Motor Gráfico 3D Vetorial em NumPy (Sem necessidade de GPU dedicada)**:
   - Matrizes de rotação composta $R = R_z(\psi) R_y(\theta) R_x(\phi)$, projeção perspectiva *pinhole*, ordenação de profundidade pelo **Algoritmo do Pintor (Z-Sorting)**, iluminação holográfica Lambert + Fresnel e **Modo de Visão Explodida** (*Disassemble View* ao pressionar `[E]`).

5. **Pipeline Híbrido de IA Generativa 3D (`Text-to-3D` e `Image-to-3D`)**:
   - **Nuvem Gratuita (`--cloud-ai`)**: Integração via `gradio_client` com modelos State-of-the-Art no Hugging Face Spaces (como **OpenAI Shap-E**), gerando malhas `.glb`/`.obj` nas GPUs da nuvem sem consumir CPU/RAM local.
   - **Síntese Local Instantânea na CPU (< 150ms)**:
     - `Text-to-3D Local`: Sintetizador paramétrico/semântico que esculpe malhas `.obj` instantaneamente offline.
     - `Image-to-3D Relief`: Converte qualquer foto 2D (ou captura ao vivo da webcam com a tecla `[I]`) em uma malha volumétrica 3D usando mapas de elevação multiescala e gradiente de Sobel.

---

## Arquitetura do Projeto

```text
stark-vision-3d/
├── main.py                       # CLI principal e loop de Realidade Aumentada
├── requirements.txt              # Dependências leves otimizadas para CPU
├── assets/
│   └── models/                   # Modelos 3D (.obj/.glb) prontos e gerados por IA
│       ├── arc_reactor.obj       # Reator Arc do Tony Stark
│       ├── jarvis_core.obj       # Matriz Geodésica J.A.R.V.I.S.
│       └── stark_drone.obj       # Drone Futurista Stark
├── src/
│   ├── config.py                 # Paleta J.A.R.V.I.S. e hiperparâmetros de visão/3D
│   ├── vision/
│   │   ├── hand_tracker.py       # Extração de 21 landmarks 3D e métricas invariantes a Z
│   │   ├── gesture_engine.py     # Máquina de estados (Pinça 1 mão e Zoom 2 mãos)
│   │   └── smoothing.py          # Filtros EMA para Posição, Rotação e Escala
│   ├── engine3d/
│   │   ├── math3d.py             # Álgebra linear 3D, projeção perspectiva e Z-sorting
│   │   ├── mesh_loader.py        # Parser nativo .OBJ + carregador universal .GLB/.STL
│   │   └── hologram_renderer.py  # Renderizador holográfico + Modo Explodir Peças
│   ├── ui/
│   │   └── jarvis_hud.py         # Interface HUD cibernética sobreposta à webcam
│   └── ai/
│       ├── generator_3d.py       # IA Text-to-3D (Cloud Shap-E + Local) e Image-to-3D
│       └── procedural_meshes.py  # Gerador matemático dos modelos Stark padrão
└── tests/                        # Suíte de testes automatizados (Pytest)
```

---

## Como Executar Localmente

### 1. Clonar e instalar dependências
```bash
pip install -r requirements.txt
```

### 2. Iniciar com a Webcam
```bash
python main.py
```

### 3. Gerar Modelos 3D com IA ou Carregar Arquivos `.OBJ` / `.GLB`
```bash
# Gerar modelo 3D a partir de texto (Local CPU instantâneo):
python main.py --prompt "dna double helix"

# Gerar modelo 3D usando GPU gratuita na nuvem (Hugging Face Shap-E):
python main.py --prompt "futuristic cyberpunk helmet" --cloud-ai

# Transformar uma imagem 2D em holograma 3D interativo:
python main.py --image minha_foto.png

# Carregar qualquer arquivo .OBJ, .GLB ou .STL:
python main.py --model caminho/para/modelo.glb
```

### 4. Modo Demonstração (Sem Webcam) e Testes
```bash
# Rodar simulação com mãos virtuais:
python main.py --demo

# Exportar vídeo .MP4 de demonstração para o portfólio:
python main.py --export-demo-video assets/demo_preview.mp4

# Rodar a suíte de testes unitários:
pytest
```

---

## Atalhos Interativos Durante a Execução

| Tecla | Ação no Sistema J.A.R.V.I.S. |
| :---: | :--- |
| `1`, `2`, `3` | Alterna entre **Arc Reactor**, **J.A.R.V.I.S. Core** e **Stark Drone** |
| `G` | Gera um novo modelo 3D por IA em tempo real |
| `I` | **Scanner 2D -> 3D**: Captura o quadro atual da webcam e converte em malha 3D na hora |
| `M` | Alterna o modo da pinça de 1 mão (`SMART_ZONES`, `ROTATE_ONLY`, `MOVE_ONLY`, `COUPLED`) |
| `V` | Alterna o estilo visual (`HOLOGRAM_SHADED`, `WIREFRAME_NEON`, `POINT_CLOUD`) |
| `E` | Ativa/desativa a **Visão Explodida** (*Disassemble View* das peças 3D) |
| `R` | Reseta posição, ângulos e escala do holograma |
| `Q` / `ESC` | Encerra a aplicação |
