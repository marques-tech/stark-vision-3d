"""
Stark Vision 3D — Ponto de Entrada Principal (CLI & Loop de Realidade Aumentada).

Exemplos de uso:
  1. Rodar com a webcam padrão (Carrega o Reator Arc do Tony Stark):
     python main.py

  2. Carregar um arquivo .OBJ ou .GLB externo:
     python main.py --model meu_modelo.glb

  3. Gerar um modelo 3D por IA a partir de texto antes de abrir a câmera:
     python main.py --prompt "dna helix structure"
     python main.py --prompt "futuristic spaceship" --cloud-ai

  4. Transformar uma foto 2D em holograma 3D interativo:
     python main.py --image foto.png

  5. Rodar simulação sem webcam (ou exportar vídeo de demonstração para o GitHub):
     python main.py --demo
     python main.py --export-demo-video assets/demo_preview.mp4
"""

import argparse
import math
from pathlib import Path
import time
from typing import List, Optional
import cv2
import numpy as np

from src.ai.generator_3d import AI3DGenerator
from src.ai.procedural_meshes import ensure_default_models
from src.config import RENDER_CFG, VISION_CFG
from src.engine3d.hologram_renderer import HologramRenderer
from src.engine3d.mesh_loader import Mesh3D, load_mesh_file
from src.ui.jarvis_hud import JarvisHUD
from src.vision.gesture_engine import GestureEngine
from src.vision.hand_tracker import (
    HandObservation,
    HandTracker,
    compute_hand_observation_from_landmarks,
)


def build_synthetic_hand(
    center_x_norm: float,
    center_y_norm: float,
    pinch_openness: float,
    wrist_roll_rad: float,
    frame_w: int,
    frame_h: int,
    label: str = "Right",
) -> HandObservation:
    """
    Constrói uma mão sintética realista (21 landmarks) para o modo `--demo`
    e exportação de vídeo sem necessidade de webcam física.
    """
    lm = np.zeros((21, 3), dtype=np.float64)
    # Pulso (0) e base do dedo médio (9) definem palm_size_norm (~0.14)
    lm[0] = [center_x_norm, center_y_norm + 0.11, 0.0]
    lm[9] = [center_x_norm, center_y_norm - 0.03, 0.0]

    # Bases dos dedos (5, 9, 13, 17) rotacionadas por wrist_roll_rad
    ca, sa = math.cos(wrist_roll_rad), math.sin(wrist_roll_rad)
    offsets_x = [-0.045, -0.015, 0.015, 0.045]
    mcp_indices = [5, 9, 13, 17]
    for idx, ox in zip(mcp_indices, offsets_x):
        rx = ox * ca
        ry = ox * sa
        lm[idx] = [center_x_norm + rx, center_y_norm - 0.03 + ry, 0.0]

    # Polegar (1..4) e Indicador (6..8) controlados por pinch_openness
    half_gap = 0.012 + 0.055 * pinch_openness
    lm[1] = [center_x_norm - 0.05, center_y_norm + 0.06, 0.0]
    lm[2] = [center_x_norm - 0.04, center_y_norm + 0.02, 0.0]
    lm[3] = [center_x_norm - 0.02, center_y_norm - 0.01, 0.0]
    lm[4] = [center_x_norm - half_gap * 0.6, center_y_norm - 0.04 + half_gap * 0.5, 0.0]

    lm[6] = [lm[5, 0], lm[5, 1] - 0.03, 0.0]
    lm[7] = [lm[5, 0], lm[5, 1] - 0.05, 0.0]
    lm[8] = [center_x_norm + half_gap * 0.6, center_y_norm - 0.04 - half_gap * 0.5, 0.0]

    # Demais dedos (médio, anelar, mindinho)
    for base_idx, tip_offset in ((9, -0.09), (13, -0.08), (17, -0.065)):
        lm[base_idx + 1] = [lm[base_idx, 0], lm[base_idx, 1] + tip_offset * 0.4, 0.0]
        lm[base_idx + 2] = [lm[base_idx, 0], lm[base_idx, 1] + tip_offset * 0.75, 0.0]
        lm[base_idx + 3] = [lm[base_idx, 0], lm[base_idx, 1] + tip_offset, 0.0]

    return compute_hand_observation_from_landmarks(
        landmarks_norm=lm,
        frame_width=frame_w,
        frame_height=frame_h,
        label=label,
    )


def generate_demo_hands_for_step(step: int, width: int, height: int) -> List[HandObservation]:
    """
    Coreografia de demonstração em 3 fases:
      - Frames 0..89:   1 Mão em Pinça -> Rotação Orbital 3D nos 3 eixos (Pitch, Yaw, Roll)
      - Frames 90..169: 2 Mãos em Pinça Simultânea -> Zoom / Escala Bi-manual estilo Tony Stark
      - Frames 170..239: 1 Mão em Pinça no Núcleo -> Agarrar e Mover o Holograma pela tela
    """
    phase = step % 240
    t = phase / 60.0

    if phase < 90:
        # Fase 1: Pinça com 1 mão girando o objeto 3D em Pitch, Yaw e Roll
        cx = 0.64 + 0.14 * math.sin(t * 2.2)
        cy = 0.48 + 0.11 * math.cos(t * 1.8)
        roll = 0.45 * math.sin(t * 2.0)
        return [build_synthetic_hand(cx, cy, pinch_openness=0.08, wrist_roll_rad=roll, frame_w=width, frame_h=height, label="Right")]

    if phase < 170:
        # Fase 2: Pinça Dupla (Zoom / Escala com as duas mãos afastando e aproximando)
        local_t = (phase - 90) / 80.0
        spread = 0.12 + 0.16 * math.sin(local_t * math.pi)
        tilt = 0.22 * math.sin(local_t * 2.0 * math.pi)
        left_hand = build_synthetic_hand(
            0.50 - spread,
            0.50 - tilt * 0.25,
            pinch_openness=0.06,
            wrist_roll_rad=-0.1,
            frame_w=width,
            frame_h=height,
            label="Left",
        )
        right_hand = build_synthetic_hand(
            0.50 + spread,
            0.50 + tilt * 0.25,
            pinch_openness=0.06,
            wrist_roll_rad=0.1,
            frame_w=width,
            frame_h=height,
            label="Right",
        )
        return [left_hand, right_hand]

    # Fase 3: Pinça no centro do objeto para arrastá-lo pela tela
    local_t = (phase - 170) / 70.0
    cx = 0.50 + 0.15 * math.sin(local_t * 2.0 * math.pi)
    cy = 0.50 + 0.08 * math.cos(local_t * 2.0 * math.pi)
    return [build_synthetic_hand(cx, cy, pinch_openness=0.07, wrist_roll_rad=0.0, frame_w=width, frame_h=height, label="Right")]


def create_cyber_grid_background(width: int, height: int, step: int = 0) -> np.ndarray:
    """Cria um fundo escuro com grade holográfica sutil para modo demo/sem câmera."""
    bg = np.full((height, width, 3), (18, 12, 6), dtype=np.uint8)
    grid_step = 64
    offset = (step * 2) % grid_step

    for x in range(0, width, grid_step):
        cv2.line(bg, (x, 0), (x, height), (34, 24, 10), 1)
    for y in range(offset, height, grid_step):
        cv2.line(bg, (0, y), (width, y), (34, 24, 10), 1)
    return bg


def export_demo_video(
    output_path: Path,
    meshes: List[Mesh3D],
    num_frames: int = 240,
    fps: int = 30,
) -> Path:
    """Renderiza um vídeo .MP4 demonstrando todos os gestos e modelos 3D."""
    w, h = VISION_CFG.camera_width, VISION_CFG.camera_height
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(output_path), fourcc, float(fps), (w, h))

    gesture_engine = GestureEngine(frame_width=w, frame_height=h)
    renderer = HologramRenderer(config=RENDER_CFG)
    hud = JarvisHUD()

    for step in range(num_frames):
        frame = create_cyber_grid_background(w, h, step)
        active_mesh = meshes[(step // 90) % len(meshes)]
        if step == 120:
            renderer.toggle_explode_view()
        elif step == 165:
            renderer.toggle_explode_view()

        hands = generate_demo_hands_for_step(step, w, h)
        transform, telemetry = gesture_engine.update(hands)
        renderer.render(frame, active_mesh, transform, telemetry.state)
        hud.draw(
            frame_bgr=frame,
            hands=hands,
            transform=transform,
            telemetry=telemetry,
            mesh=active_mesh,
            render_style=renderer.style,
            fps=float(fps),
            status_banner="DEMO SIMULATION: 1-HAND 3D ROTATE/MOVE & 2-HAND ZOOM",
        )
        writer.write(frame)

    writer.release()
    return output_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stark Vision 3D — Interação Holográfica com Mãos e IA Generativa 3D"
    )
    parser.add_argument("--camera", type=int, default=0, help="Índice da webcam (padrão: 0)")
    parser.add_argument("--model", type=str, default=None, help="Caminho para arquivo .obj, .glb, .stl")
    parser.add_argument("--prompt", type=str, default=None, help="Prompt de texto para gerar modelo 3D com IA")
    parser.add_argument("--image", type=str, default=None, help="Caminho de imagem 2D para converter em 3D")
    parser.add_argument("--cloud-ai", action="store_true", help="Usar GPU gratuita do HuggingFace (Shap-E) para --prompt")
    parser.add_argument("--demo", action="store_true", help="Executar com mãos virtuais simuladas (sem webcam)")
    parser.add_argument("--export-demo-video", type=str, default=None, help="Exporta um vídeo .mp4 da simulação e encerra")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    base_dir = Path(__file__).resolve().parent
    models_dir = base_dir / "assets" / "models"

    # 1. Garante que os 3 modelos 3D padrão do Tony Stark existam em assets/models/
    default_paths = ensure_default_models(models_dir)
    loaded_meshes: List[Mesh3D] = [
        load_mesh_file(p, max_faces=RENDER_CFG.max_faces_cpu) for p in default_paths
    ]
    ai_gen = AI3DGenerator(
        output_dir=models_dir / "generated",
        max_faces_cpu=RENDER_CFG.max_faces_cpu,
    )

    status_banner: Optional[str] = None
    active_idx = 0

    # 2. Se o usuário passou --model, --prompt ou --image na linha de comando
    if args.model:
        custom_mesh = load_mesh_file(args.model, max_faces=RENDER_CFG.max_faces_cpu)
        loaded_meshes.insert(0, custom_mesh)
        status_banner = f"MODELO CARREGADO: {custom_mesh.name}"

    if args.prompt:
        print(f"[J.A.R.V.I.S.] Gerando modelo 3D via IA para o prompt: '{args.prompt}'...")
        ai_mesh, saved_path, backend = ai_gen.text_to_3d(
            args.prompt, use_cloud_api=args.cloud_ai
        )
        loaded_meshes.insert(0, ai_mesh)
        status_banner = f"IA 3D ({backend}): {ai_mesh.name} -> {saved_path.name}"

    if args.image:
        print(f"[J.A.R.V.I.S.] Convertendo imagem 2D '{args.image}' em malha 3D...")
        img_mesh, saved_path = ai_gen.image_to_3d_relief_cpu(args.image)
        loaded_meshes.insert(0, img_mesh)
        status_banner = f"IMAGE-TO-3D CRIADO: {saved_path.name}"

    # 3. Modo de exportação headless de vídeo MP4
    if args.export_demo_video:
        out_video = Path(args.export_demo_video)
        print(f"[J.A.R.V.I.S.] Renderizando vídeo de demonstração em {out_video}...")
        export_demo_video(out_video, loaded_meshes)
        print(f"[J.A.R.V.I.S.] Vídeo concluído com sucesso: {out_video}")
        return

    # 4. Inicializa rastreador MediaPipe, motor de gestos, renderizador 3D e HUD
    w, h = VISION_CFG.camera_width, VISION_CFG.camera_height
    cap = None
    use_demo = args.demo

    if not use_demo:
        cap = cv2.VideoCapture(args.camera)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
        if not cap.isOpened():
            print("[AVISO] Webcam não detectada. Ativando modo de simulação (--demo) automaticamente.")
            use_demo = True

    tracker = HandTracker(
        max_hands=VISION_CFG.max_num_hands,
        min_detection_confidence=VISION_CFG.min_detection_confidence,
        min_tracking_confidence=VISION_CFG.min_tracking_confidence,
    )
    gesture_engine = GestureEngine(frame_width=w, frame_height=h, config=VISION_CFG)
    renderer = HologramRenderer(config=RENDER_CFG)
    hud = JarvisHUD()

    prev_time = time.perf_counter()
    fps_ema = 30.0
    step = 0
    ai_prompt_presets = [
        "dna double helix",
        "quantum harmonic crystal",
        "arc reactor core",
        "stark stealth drone",
    ]
    preset_counter = 0

    print("\n==================================================================")
    print("  STARK VISION 3D — SISTEMA J.A.R.V.I.S. INICIADO")
    print("==================================================================")
    print("  * Pinça com 1 Mão (Anel Externo): Gira o modelo 3D em 3 Eixos")
    print("  * Pinça com 1 Mão (Núcleo Central): Agarra e move o modelo")
    print("  * Pinça com as 2 Mãos simultâneas: Zoom / Escala proporcional")
    print("  * Teclas: [1-3] Modelos | [G] Gerar IA 3D | [I] Foto Webcam->3D")
    print("            [M] Modo | [V] Visual | [E] Explodir | [R] Reset | [Q] Sair")
    print("==================================================================\n")

    try:
        while True:
            step += 1
            if not use_demo and cap is not None:
                ok, raw_frame = cap.read()
                if not ok:
                    break
                # Espelha horizontalmente (efeito espelho natural para interação com as mãos)
                frame = cv2.flip(raw_frame, 1)
                if frame.shape[1] != w or frame.shape[0] != h:
                    frame = cv2.resize(frame, (w, h))
                hands = tracker.process_frame(frame)
            else:
                frame = create_cyber_grid_background(w, h, step)
                hands = generate_demo_hands_for_step(step, w, h)

            active_mesh = loaded_meshes[active_idx % len(loaded_meshes)]

            # Atualiza física de gestos e renderiza o objeto 3D + HUD
            transform, telemetry = gesture_engine.update(hands)
            renderer.render(frame, active_mesh, transform, telemetry.state)

            now = time.perf_counter()
            dt = max(now - prev_time, 1e-4)
            prev_time = now
            fps_ema = 0.90 * fps_ema + 0.10 * (1.0 / dt)

            hud.draw(
                frame_bgr=frame,
                hands=hands,
                transform=transform,
                telemetry=telemetry,
                mesh=active_mesh,
                render_style=renderer.style,
                fps=fps_ema,
                status_banner=status_banner,
            )

            cv2.imshow("Stark Vision 3D - J.A.R.V.I.S. Holographic Interface", frame)
            key = cv2.waitKey(1) & 0xFF

            if key in (ord("q"), 27):
                break
            elif key in (ord("1"), ord("2"), ord("3")):
                idx = key - ord("1")
                if idx < len(loaded_meshes):
                    active_idx = idx
                    status_banner = f"MODELO ATIVO: {loaded_meshes[active_idx].name.upper()}"
            elif key == ord("m"):
                new_mode = gesture_engine.cycle_mode()
                status_banner = f"MODO 1-MAO ALTERADO PARA: {new_mode.value}"
            elif key == ord("v"):
                new_style = renderer.cycle_style()
                status_banner = f"ESTILO DE RENDERIZACAO: {new_style.value}"
            elif key == ord("e"):
                exploded = renderer.toggle_explode_view()
                status_banner = "VISAO EXPLODIDA: ATIVADA" if exploded else "VISAO EXPLODIDA: MONTADA"
            elif key == ord("r"):
                gesture_engine.reset_transform()
                status_banner = "TRANSFORMACAO 3D RESETADA"
            elif key == ord("g"):
                prompt_text = ai_prompt_presets[preset_counter % len(ai_prompt_presets)]
                preset_counter += 1
                ai_mesh, saved_path, backend = ai_gen.text_to_3d(
                    prompt_text, use_cloud_api=args.cloud_ai
                )
                loaded_meshes.append(ai_mesh)
                active_idx = len(loaded_meshes) - 1
                status_banner = f"IA GEROU '{prompt_text.upper()}' ({saved_path.name})"
            elif key == ord("i"):
                # Captura o centro do quadro atual e converte em malha 3D na hora!
                ch, cw = frame.shape[:2]
                crop = frame[ch // 4 : 3 * ch // 4, cw // 4 : 3 * cw // 4]
                img_mesh, saved_path = ai_gen.image_to_3d_relief_cpu(
                    crop, name=f"scan3d_{step}"
                )
                loaded_meshes.append(img_mesh)
                active_idx = len(loaded_meshes) - 1
                status_banner = f"SCAN 2D->3D CONCLUIDO: {saved_path.name}"

    finally:
        tracker.close()
        if cap is not None:
            cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
