"""
Configurações globais do Stark Vision 3D.

Define paleta de cores no padrão BGR (OpenCV) inspirada no HUD do J.A.R.V.I.S.,
hiperparâmetros de detecção de gestos (pinça e escala) e configurações de câmera.
"""

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class JarvisColors:
    """Paleta de cores no formato BGR (Blue, Green, Red) do OpenCV."""

    CYAN_PRIMARY: Tuple[int, int, int] = (255, 225, 0)       # Ciano brilhante principal
    CYAN_GLOW: Tuple[int, int, int] = (255, 160, 0)          # Azul-ciano intermediário
    CYAN_DARK: Tuple[int, int, int] = (140, 80, 0)           # Azul escuro para preenchimento
    ORANGE_ALERT: Tuple[int, int, int] = (0, 165, 255)       # Laranja (pinça ativa / lock)
    GOLD_ACCENT: Tuple[int, int, int] = (60, 215, 255)       # Dourado Stark (zoom bi-manual)
    WHITE_CORE: Tuple[int, int, int] = (255, 255, 240)       # Branco quente para núcleos e texto
    HUD_BG: Tuple[int, int, int] = (28, 18, 8)               # Fundo translúcido de painéis


@dataclass
class VisionConfig:
    """Hiperparâmetros de Visão Computacional e Estabilização."""

    camera_width: int = 1280
    camera_height: int = 720
    max_num_hands: int = 2
    min_detection_confidence: float = 0.7
    min_tracking_confidence: float = 0.7

    # Razão entre distância (polegar-indicador) e tamanho da palma (pulso-base do dedo médio).
    # Tornar o limiar relativo ao tamanho da palma garante invariância à profundidade!
    pinch_start_ratio: float = 0.34
    pinch_release_ratio: float = 0.44  # Histerese para evitar flicker ao segurar o objeto

    # Fator alpha do Filtro de Média Móvel Exponencial (EMA):
    # Valores menores = mais suave (menos tremor); valores maiores = menor latência.
    ema_alpha_position: float = 0.35
    ema_alpha_rotation: float = 0.28
    ema_alpha_scale: float = 0.30

    # Sensibilidade de manipulação 3D
    rotation_sensitivity: float = 3.2  # Multiplicador de radianos por deslocamento normalizado
    min_scale: float = 0.25
    max_scale: float = 3.50


@dataclass
class RenderConfig:
    """Parâmetros do motor de projeção 3D em CPU."""

    focal_length: float = 850.0        # Distância focal virtual (câmera pinhole)
    camera_distance: float = 4.2       # Distância Z do objeto em relação à câmera
    base_model_radius: float = 165.0   # Raio base em pixels na escala 1.0
    max_faces_cpu: int = 1800          # Limite automático de faces para garantir 30-60+ FPS na CPU
    wireframe_thickness: int = 1
    face_alpha: float = 0.28           # Transparência do preenchimento holográfico
    show_axes: bool = True             # Exibe eixos X, Y, Z locais no centro do modelo


COLORS = JarvisColors()
VISION_CFG = VisionConfig()
RENDER_CFG = RenderConfig()
