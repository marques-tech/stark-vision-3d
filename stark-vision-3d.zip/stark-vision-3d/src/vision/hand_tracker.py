"""
Rastreador de Mãos 3D baseado em MediaPipe Hands.

Extrai os 21 marcos anatômicos (landmarks) de até 2 mãos em tempo real e calcula
métricas invariantes à escala/profundidade:
  - Tamanho aparente da palma (distância entre Pulso [0] e Base do Dedo Médio [9]).
  - Razão de Pinça (Pinch Ratio): distância Polegar [4] <-> Indicador [8] dividida
    pelo tamanho da palma. Isso garante que o gesto de pinça funcione tanto perto
    quanto longe da webcam!
  - Ângulo de Roll do pulso (rotação no eixo Z da câmera).
"""

from dataclasses import dataclass
from typing import List, Optional
import math
import cv2
import numpy as np


@dataclass
class HandObservation:
    """Representa os dados geométricos extraídos de uma mão em um frame."""

    label: str                        # "Left" ou "Right"
    score: float                      # Confiança da detecção [0.0, 1.0]
    landmarks_norm: np.ndarray        # Shape (21, 3) normalizado [0..1]
    landmarks_px: np.ndarray          # Shape (21, 2) em pixels (x, y)
    palm_center_px: np.ndarray        # Shape (2,) centro da palma em pixels
    pinch_center_px: np.ndarray       # Shape (2,) ponto médio entre polegar(4) e indicador(8)
    pinch_center_norm: np.ndarray     # Shape (2,) ponto médio normalizado [0..1]
    palm_size_norm: float             # Tamanho de referência da palma (landmark 0 -> 9)
    pinch_distance_norm: float        # Distância Euclidiana polegar(4) <-> indicador(8)
    pinch_ratio: float                # pinch_distance_norm / palm_size_norm (invariante a Z)
    wrist_roll_rad: float             # Ângulo de inclinação planar da mão (eixo Z)
    index_tip_px: np.ndarray          # Shape (2,) ponta do indicador (landmark 8)
    thumb_tip_px: np.ndarray          # Shape (2,) ponta do polegar (landmark 4)


def compute_hand_observation_from_landmarks(
    landmarks_norm: np.ndarray,
    frame_width: int,
    frame_height: int,
    label: str = "Right",
    score: float = 0.99,
) -> HandObservation:
    """
    Calcula todas as propriedades geométricas a partir de uma matriz (21, 3) de landmarks.
    Separado do MediaPipe para permitir testes unitários determinísticos e modo simulação.
    """
    lm = np.asarray(landmarks_norm, dtype=np.float64)
    if lm.shape != (21, 3):
        raise ValueError(f"Esperado shape (21, 3) para landmarks, recebido {lm.shape}")

    # Coordenadas em pixels na tela
    lm_px = np.zeros((21, 2), dtype=np.float64)
    lm_px[:, 0] = lm[:, 0] * frame_width
    lm_px[:, 1] = lm[:, 1] * frame_height

    # Centro da palma: média entre Pulso (0) e bases dos dedos (5, 9, 13, 17)
    palm_indices = [0, 5, 9, 13, 17]
    palm_center_px = np.mean(lm_px[palm_indices], axis=0)

    # Escala da palma no plano corrigido pela razão de aspecto
    aspect = frame_width / max(float(frame_height), 1.0)
    wrist_xy = np.array([lm[0, 0] * aspect, lm[0, 1]])
    mid_mcp_xy = np.array([lm[9, 0] * aspect, lm[9, 1]])
    palm_size_norm = float(np.linalg.norm(mid_mcp_xy - wrist_xy))
    palm_size_norm = max(palm_size_norm, 1e-4)

    # Pontas do polegar (4) e indicador (8)
    thumb_xy_corr = np.array([lm[4, 0] * aspect, lm[4, 1]])
    index_xy_corr = np.array([lm[8, 0] * aspect, lm[8, 1]])
    pinch_distance_norm = float(np.linalg.norm(thumb_xy_corr - index_xy_corr))

    # Razão de pinça invariante à distância da mão até a câmera
    pinch_ratio = pinch_distance_norm / palm_size_norm

    pinch_center_px = 0.5 * (lm_px[4] + lm_px[8])
    pinch_center_norm = 0.5 * (lm[4, :2] + lm[8, :2])

    # Ângulo de Roll do pulso: vetor entre a base do indicador (5) e base do mindinho (17)
    vec_across_palm = lm_px[17] - lm_px[5]
    wrist_roll_rad = math.atan2(float(vec_across_palm[1]), float(vec_across_palm[0]))

    return HandObservation(
        label=label,
        score=score,
        landmarks_norm=lm,
        landmarks_px=lm_px,
        palm_center_px=palm_center_px,
        pinch_center_px=pinch_center_px,
        pinch_center_norm=pinch_center_norm,
        palm_size_norm=palm_size_norm,
        pinch_distance_norm=pinch_distance_norm,
        pinch_ratio=pinch_ratio,
        wrist_roll_rad=wrist_roll_rad,
        index_tip_px=lm_px[8].copy(),
        thumb_tip_px=lm_px[4].copy(),
    )


class HandTracker:
    """
    Detector e rastreador de mãos em tempo real via MediaPipe Hands.
    Otimizado para rodar em CPU com baixa latência (model_complexity=0).
    """

    # Conexões anatômicas dos 21 pontos da mão para renderização do esqueleto HUD
    HAND_CONNECTIONS = [
        (0, 1), (1, 2), (2, 3), (3, 4),        # Polegar
        (0, 5), (5, 6), (6, 7), (7, 8),        # Indicador
        (5, 9), (9, 10), (10, 11), (11, 12),   # Médio
        (9, 13), (13, 14), (14, 15), (15, 16), # Anelar
        (13, 17), (0, 17), (17, 18), (18, 19), (19, 20),  # Mindinho e palma
    ]

    def __init__(
        self,
        max_hands: int = 2,
        min_detection_confidence: float = 0.7,
        min_tracking_confidence: float = 0.7,
        model_complexity: int = 0,  # 0 = Lite/Fast para 30-60+ FPS na CPU
    ):
        self.max_hands = max_hands
        self._mp_hands = None
        self._detector = None

        try:
            import mediapipe as mp
            if hasattr(mp, "solutions") and hasattr(mp.solutions, "hands"):
                self._mp_hands = mp.solutions.hands
                self._detector = self._mp_hands.Hands(
                    static_image_mode=False,
                    max_num_hands=max_hands,
                    model_complexity=model_complexity,
                    min_detection_confidence=min_detection_confidence,
                    min_tracking_confidence=min_tracking_confidence,
                )
        except ImportError:
            self._detector = None

    def process_frame(self, frame_bgr: np.ndarray) -> List[HandObservation]:
        """
        Processa um frame BGR do OpenCV e retorna a lista de mãos detectadas.
        """
        if self._detector is None:
            return []

        h, w = frame_bgr.shape[:2]
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        frame_rgb.flags.writeable = False
        results = self._detector.process(frame_rgb)

        observations: List[HandObservation] = []
        if not results.multi_hand_landmarks:
            return observations

        handedness_list = results.multi_handedness or []
        for idx, hand_lms in enumerate(results.multi_hand_landmarks):
            coords = np.array(
                [[lm.x, lm.y, lm.z] for lm in hand_lms.landmark],
                dtype=np.float64,
            )
            label = "Right"
            score = 0.95
            if idx < len(handedness_list) and handedness_list[idx].classification:
                cls = handedness_list[idx].classification[0]
                label = cls.label
                score = float(cls.score)

            obs = compute_hand_observation_from_landmarks(
                landmarks_norm=coords,
                frame_width=w,
                frame_height=h,
                label=label,
                score=score,
            )
            observations.append(obs)

        return observations

    def close(self) -> None:
        if self._detector is not None:
            self._detector.close()
