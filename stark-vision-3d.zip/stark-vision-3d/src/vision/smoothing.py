"""
Filtros de Suavização Temporal (EMA - Exponential Moving Average).

Em Visão Computacional com webcams comuns, as coordenadas dos landmarks
possuem ruído de alta frequência (jitter/tremor). Este módulo implementa:
  1. EMAFilter: Filtro passa-baixa vetorial/escalar:
     y_t = alpha * x_t + (1 - alpha) * y_{t-1}
  2. TransformSmoother: Estabilizador dedicado para Posição (x, y),
     Rotação Euleriana (rx, ry, rz) e Escala (scale) do holograma 3D.
"""

from typing import Optional
import numpy as np


class EMAFilter:
    """
    Filtro de Média Móvel Exponencial para escalares ou vetores NumPy.
    """

    def __init__(self, alpha: float = 0.3, initial_value: Optional[np.ndarray] = None):
        if not (0.0 < alpha <= 1.0):
            raise ValueError("O parâmetro alpha do EMA deve estar no intervalo (0, 1].")
        self.alpha = float(alpha)
        self.state: Optional[np.ndarray] = (
            np.array(initial_value, dtype=np.float64) if initial_value is not None else None
        )

    def reset(self, value: Optional[np.ndarray] = None) -> None:
        """Reinicia o estado interno do filtro."""
        self.state = np.array(value, dtype=np.float64) if value is not None else None

    def update(self, measurement: np.ndarray | float) -> np.ndarray:
        """
        Aplica um passo de filtragem recursiva sobre a nova medição.
        """
        arr = np.asarray(measurement, dtype=np.float64)
        if self.state is None:
            self.state = arr.copy()
        else:
            self.state = self.alpha * arr + (1.0 - self.alpha) * self.state
        return self.state.copy()


class TransformSmoother:
    """
    Suavizador completo para o estado de transformação 3D (Posição, Rotação e Escala).
    """

    def __init__(
        self,
        alpha_pos: float = 0.35,
        alpha_rot: float = 0.28,
        alpha_scale: float = 0.30,
    ):
        self.pos_filter = EMAFilter(alpha=alpha_pos)
        self.rot_filter = EMAFilter(alpha=alpha_rot)
        self.scale_filter = EMAFilter(alpha=alpha_scale)

    def update(
        self,
        position_xy: np.ndarray,
        rotation_xyz: np.ndarray,
        scale: float,
    ) -> tuple[np.ndarray, np.ndarray, float]:
        """Retorna (pos_suavizada, rot_suavizada, escala_suavizada)."""
        smooth_pos = self.pos_filter.update(position_xy)
        smooth_rot = self.rot_filter.update(rotation_xyz)
        smooth_scale = float(self.scale_filter.update(scale))
        return smooth_pos, smooth_rot, smooth_scale
