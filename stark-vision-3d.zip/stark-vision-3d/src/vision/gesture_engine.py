"""
Motor de Gestos Espaciais 3D (Stark Gesture Engine).

Implementa a máquina de estados para manipulação holográfica:
  1. Pinça com 1 Mão (Agarrar, Mover e Rotacionar nos 3 eixos):
     - Se a pinça iniciar sobre o Núcleo Central do objeto (ou no modo MOVE):
       Arrasta o objeto livremente pelos eixos (X, Y) da tela + gira no eixo Z (Roll).
     - Se a pinça iniciar no Anel Orbital / Espaço externo (ou no modo ROTATE):
       Rotaciona o modelo 3D em 360° nos 3 eixos:
         * Yaw (Eixo Y)   <- Movimento horizontal da pinça (dx)
         * Pitch (Eixo X) <- Movimento vertical da pinça (dy)
         * Roll (Eixo Z)  <- Giro planar do pulso (d_theta)
     - No modo COUPLED, translada suavemente e rotaciona ao mesmo tempo.

  2. Pinça Dupla Simultânea (Zoom / Escala com as 2 Mãos):
     - Quando as duas mãos entram em pinça simultaneamente:
         * Escala (Zoom)  <- Razão entre a distância atual entre as mãos e a distância inicial:
                             S(t) = S_0 * (d(t) / d_0)
         * Posição (X, Y) <- Acompanha o ponto médio entre as duas mãos
         * Roll (Eixo Z)  <- Inclinação da linha de tensão que conecta as duas mãos
"""

from dataclasses import dataclass, field
from enum import Enum
import math
from typing import List, Optional
import numpy as np

from src.config import VISION_CFG, VisionConfig
from src.vision.hand_tracker import HandObservation
from src.vision.smoothing import TransformSmoother


class GestureState(str, Enum):
    """Estados ativos da interação gestual."""

    IDLE = "IDLE"                             # Sem pinça ativa (rotação inercial suave opcional)
    SINGLE_ROTATE_3D = "SINGLE_ROTATE_3D"     # 1 mão em pinça: rotação orbital 3 eixos (Rx, Ry, Rz)
    SINGLE_MOVE_3D = "SINGLE_MOVE_3D"         # 1 mão em pinça no núcleo: translação (X, Y) + Roll (Rz)
    SINGLE_COUPLED = "SINGLE_COUPLED"         # 1 mão em pinça: translação + rotação 3D combinadas
    DUAL_ZOOM_SCALE = "DUAL_ZOOM_SCALE"       # 2 mãos em pinça: zoom/escala bi-manual + translação


class ManipulationMode(str, Enum):
    """Modo de comportamento da pinça com 1 mão."""

    SMART_ZONES = "SMART_ZONES"   # Núcleo central = Move | Anel externo = Rotaciona 3 eixos
    ROTATE_ONLY = "ROTATE_ONLY"   # 1 mão sempre rotaciona nos 3 eixos
    MOVE_ONLY = "MOVE_ONLY"       # 1 mão sempre move o objeto
    COUPLED = "COUPLED"           # 1 mão move e rotaciona simultaneamente


@dataclass
class HologramTransform:
    """Estado geométrico 3D instantâneo do objeto holográfico."""

    position_px: np.ndarray = field(default_factory=lambda: np.array([640.0, 360.0], dtype=np.float64))
    rotation_rad: np.ndarray = field(default_factory=lambda: np.array([0.35, -0.45, 0.0], dtype=np.float64))
    scale: float = 1.0


@dataclass
class GestureTelemetry:
    """Telemetria detalhada do frame atual para exibição no HUD do J.A.R.V.I.S."""

    state: GestureState
    mode: ManipulationMode
    active_hands: int
    pinching_hands: List[HandObservation]
    dual_hand_distance_px: Optional[float] = None
    grab_core_radius_px: float = 75.0


class GestureEngine:
    """
    Controlador gestual 3D com histerese de pinça e filtro EMA anti-jitter.
    """

    def __init__(
        self,
        frame_width: int = 1280,
        frame_height: int = 720,
        config: VisionConfig = VISION_CFG,
        auto_idle_spin: bool = True,
    ):
        self.frame_width = frame_width
        self.frame_height = frame_height
        self.config = config
        self.auto_idle_spin = auto_idle_spin
        self.mode = ManipulationMode.SMART_ZONES

        # Transformação alvo (bruta) e suavizada (filtrada por EMA)
        center = np.array([frame_width / 2.0, frame_height / 2.0], dtype=np.float64)
        init_rot = np.array([0.35, -0.45, 0.0], dtype=np.float64)
        self.raw_transform = HologramTransform(
            position_px=center.copy(),
            rotation_rad=init_rot.copy(),
            scale=1.0,
        )
        self.smooth_transform = HologramTransform(
            position_px=center.copy(),
            rotation_rad=init_rot.copy(),
            scale=1.0,
        )

        self.smoother = TransformSmoother(
            alpha_pos=config.ema_alpha_position,
            alpha_rot=config.ema_alpha_rotation,
            alpha_scale=config.ema_alpha_scale,
        )

        self.state = GestureState.IDLE
        self._hand_pinch_active: dict[str, bool] = {}

        # Âncoras da interação com 1 mão
        self._single_anchor_pinch_norm: Optional[np.ndarray] = None
        self._single_anchor_pinch_px: Optional[np.ndarray] = None
        self._single_anchor_wrist_roll: float = 0.0
        self._single_anchor_rot: Optional[np.ndarray] = None
        self._single_anchor_pos: Optional[np.ndarray] = None

        # Âncoras da interação bi-manual (2 mãos em pinça)
        self._dual_anchor_dist_px: Optional[float] = None
        self._dual_anchor_scale: float = 1.0
        self._dual_anchor_midpoint_px: Optional[np.ndarray] = None
        self._dual_anchor_pos: Optional[np.ndarray] = None
        self._dual_anchor_angle_rad: float = 0.0
        self._dual_anchor_rot_z: float = 0.0

    def reset_transform(self) -> None:
        """Reposiciona o holograma no centro da tela com escala e rotação padrão."""
        center = np.array([self.frame_width / 2.0, self.frame_height / 2.0], dtype=np.float64)
        init_rot = np.array([0.35, -0.45, 0.0], dtype=np.float64)
        self.raw_transform = HologramTransform(center.copy(), init_rot.copy(), 1.0)
        self.smooth_transform = HologramTransform(center.copy(), init_rot.copy(), 1.0)
        self.smoother.pos_filter.reset(center)
        self.smoother.rot_filter.reset(init_rot)
        self.smoother.scale_filter.reset(np.array(1.0))
        self.state = GestureState.IDLE

    def cycle_mode(self) -> ManipulationMode:
        """Alterna entre os modos de manipulação de 1 mão."""
        modes = list(ManipulationMode)
        next_idx = (modes.index(self.mode) + 1) % len(modes)
        self.mode = modes[next_idx]
        self._clear_anchors()
        return self.mode

    def _is_hand_pinching(self, hand: HandObservation, hand_key: str) -> bool:
        """
        Avalia se a mão está em gesto de pinça aplicando histerese:
        - Para iniciar a pinça: pinch_ratio < pinch_start_ratio
        - Para soltar a pinça:  pinch_ratio > pinch_release_ratio
        """
        was_pinching = self._hand_pinch_active.get(hand_key, False)
        if not was_pinching:
            is_pinching = hand.pinch_ratio <= self.config.pinch_start_ratio
        else:
            is_pinching = hand.pinch_ratio <= self.config.pinch_release_ratio
        self._hand_pinch_active[hand_key] = is_pinching
        return is_pinching

    def _clear_anchors(self) -> None:
        self._single_anchor_pinch_norm = None
        self._single_anchor_pinch_px = None
        self._dual_anchor_dist_px = None

    def update(self, hands: List[HandObservation]) -> tuple[HologramTransform, GestureTelemetry]:
        """
        Atualiza o estado do holograma 3D com base nas mãos detectadas no frame atual.
        """
        pinching_hands: List[HandObservation] = []
        active_keys = set()

        for idx, hand in enumerate(hands):
            key = f"{hand.label}_{idx}"
            active_keys.add(key)
            if self._is_hand_pinching(hand, key):
                pinching_hands.append(hand)

        # Limpa estados de mãos que saíram do quadro
        for k in list(self._hand_pinch_active.keys()):
            if k not in active_keys:
                del self._hand_pinch_active[k]

        grab_core_radius = 78.0 * float(np.clip(self.smooth_transform.scale, 0.65, 1.8))
        dual_dist_px: Optional[float] = None

        # =====================================================================
        # CASO 1: DUAS MÃOS EM PINÇA -> ZOOM / ESCALA + TRANSLAÇÃO BI-MANUAL
        # =====================================================================
        if len(pinching_hands) >= 2:
            # Ordena pela coordenada X para consistência entre frames
            h1, h2 = sorted(pinching_hands[:2], key=lambda h: float(h.pinch_center_px[0]))
            p1 = h1.pinch_center_px
            p2 = h2.pinch_center_px

            vec = p2 - p1
            current_dist = max(float(np.linalg.norm(vec)), 12.0)
            dual_dist_px = current_dist
            current_midpoint = 0.5 * (p1 + p2)
            current_angle = math.atan2(float(vec[1]), float(vec[0]))

            if self.state != GestureState.DUAL_ZOOM_SCALE or self._dual_anchor_dist_px is None:
                # Inicializa âncora bi-manual
                self.state = GestureState.DUAL_ZOOM_SCALE
                self._dual_anchor_dist_px = current_dist
                self._dual_anchor_scale = self.raw_transform.scale
                self._dual_anchor_midpoint_px = current_midpoint.copy()
                self._dual_anchor_pos = self.raw_transform.position_px.copy()
                self._dual_anchor_angle_rad = current_angle
                self._dual_anchor_rot_z = float(self.raw_transform.rotation_rad[2])
                self._single_anchor_pinch_norm = None
            else:
                # 1. Escala proporcional à razão das distâncias entre as duas pinças
                scale_ratio = current_dist / max(self._dual_anchor_dist_px, 12.0)
                new_scale = self._dual_anchor_scale * scale_ratio
                self.raw_transform.scale = float(
                    np.clip(new_scale, self.config.min_scale, self.config.max_scale)
                )

                # 2. Translação acompanhando o ponto médio entre as duas mãos
                delta_mid = current_midpoint - self._dual_anchor_midpoint_px
                self.raw_transform.position_px = self._dual_anchor_pos + delta_mid

                # 3. Rotação Z (Roll) ao girar as duas mãos como um volante
                delta_angle = self._unwrap_angle_delta(current_angle - self._dual_anchor_angle_rad)
                self.raw_transform.rotation_rad[2] = self._dual_anchor_rot_z + delta_angle

        # =====================================================================
        # CASO 2: UMA MÃO EM PINÇA -> ROTAÇÃO 3 EIXOS E/OU TRANSLAÇÃO
        # =====================================================================
        elif len(pinching_hands) == 1:
            hand = pinching_hands[0]
            self._dual_anchor_dist_px = None

            # Se acabamos de entrar na pinça de 1 mão (ou viemos do zoom de 2 mãos)
            if self._single_anchor_pinch_norm is None or self.state == GestureState.DUAL_ZOOM_SCALE:
                self._single_anchor_pinch_norm = hand.pinch_center_norm.copy()
                self._single_anchor_pinch_px = hand.pinch_center_px.copy()
                self._single_anchor_wrist_roll = hand.wrist_roll_rad
                self._single_anchor_rot = self.raw_transform.rotation_rad.copy()
                self._single_anchor_pos = self.raw_transform.position_px.copy()

                dist_to_center = float(
                    np.linalg.norm(hand.pinch_center_px - self.smooth_transform.position_px)
                )
                if self.mode == ManipulationMode.MOVE_ONLY:
                    self.state = GestureState.SINGLE_MOVE_3D
                elif self.mode == ManipulationMode.ROTATE_ONLY:
                    self.state = GestureState.SINGLE_ROTATE_3D
                elif self.mode == ManipulationMode.COUPLED:
                    self.state = GestureState.SINGLE_COUPLED
                else:
                    # SMART_ZONES: Pinçar no núcleo move o holograma; fora dele rotaciona em 3D
                    if dist_to_center <= grab_core_radius:
                        self.state = GestureState.SINGLE_MOVE_3D
                    else:
                        self.state = GestureState.SINGLE_ROTATE_3D
            else:
                delta_norm = hand.pinch_center_norm - self._single_anchor_pinch_norm
                delta_px = hand.pinch_center_px - self._single_anchor_pinch_px
                delta_roll = self._unwrap_angle_delta(
                    hand.wrist_roll_rad - self._single_anchor_wrist_roll
                )

                if self.state == GestureState.SINGLE_MOVE_3D:
                    self.raw_transform.position_px = self._single_anchor_pos + delta_px
                    self.raw_transform.rotation_rad[2] = self._single_anchor_rot[2] + delta_roll * 0.7

                elif self.state == GestureState.SINGLE_ROTATE_3D:
                    sens = self.config.rotation_sensitivity
                    # Deslocamento horizontal (dx) -> Yaw (Ry)
                    # Deslocamento vertical (dy)   -> Pitch (Rx)
                    # Inclinação do pulso          -> Roll (Rz)
                    self.raw_transform.rotation_rad[0] = (
                        self._single_anchor_rot[0] - float(delta_norm[1]) * sens
                    )
                    self.raw_transform.rotation_rad[1] = (
                        self._single_anchor_rot[1] + float(delta_norm[0]) * sens
                    )
                    self.raw_transform.rotation_rad[2] = (
                        self._single_anchor_rot[2] + delta_roll
                    )

                elif self.state == GestureState.SINGLE_COUPLED:
                    sens = self.config.rotation_sensitivity
                    self.raw_transform.position_px = self._single_anchor_pos + delta_px
                    self.raw_transform.rotation_rad[0] = (
                        self._single_anchor_rot[0] - float(delta_norm[1]) * sens
                    )
                    self.raw_transform.rotation_rad[1] = (
                        self._single_anchor_rot[1] + float(delta_norm[0]) * sens
                    )
                    self.raw_transform.rotation_rad[2] = (
                        self._single_anchor_rot[2] + delta_roll
                    )

        # =====================================================================
        # CASO 3: NENHUMA MÃO EM PINÇA -> IDLE (FLUTUAÇÃO HOLOGRÁFICA)
        # =====================================================================
        else:
            self.state = GestureState.IDLE
            self._clear_anchors()
            if self.auto_idle_spin:
                self.raw_transform.rotation_rad[1] += 0.008

        # Aplica o filtro de suavização temporal EMA para eliminar tremores
        s_pos, s_rot, s_scale = self.smoother.update(
            position_xy=self.raw_transform.position_px,
            rotation_xyz=self.raw_transform.rotation_rad,
            scale=self.raw_transform.scale,
        )
        self.smooth_transform = HologramTransform(
            position_px=s_pos,
            rotation_rad=s_rot,
            scale=s_scale,
        )

        telemetry = GestureTelemetry(
            state=self.state,
            mode=self.mode,
            active_hands=len(hands),
            pinching_hands=pinching_hands,
            dual_hand_distance_px=dual_dist_px,
            grab_core_radius_px=grab_core_radius,
        )
        return self.smooth_transform, telemetry

    @staticmethod
    def _unwrap_angle_delta(delta_rad: float) -> float:
        """Mantém a diferença angular contínua no intervalo [-pi, pi]."""
        while delta_rad > math.pi:
            delta_rad -= 2.0 * math.pi
        while delta_rad < -math.pi:
            delta_rad += 2.0 * math.pi
        return delta_rad
