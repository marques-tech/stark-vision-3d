"""Interface Visual HUD inspirada no sistema J.A.R.V.I.S. (Tony Stark)."""
