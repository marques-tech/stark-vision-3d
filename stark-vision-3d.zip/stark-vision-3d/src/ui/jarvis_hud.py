"""
Renderizador do HUD (Head-Up Display) Cibernético J.A.R.V.I.S.

Desenha elementos visuais sobre o vídeo da webcam:
  - Esqueleto futurista das mãos com anéis telemétricos no polegar (4) e indicador (8)
  - Feixe de energia de pinça (1 mão) conectado ao centro do objeto 3D
  - Linha de tensão bi-manual (2 mãos) com leitura em tempo real do fator de Zoom/Escala
  - Painel superior de telemetria (FPS, Vértices/Faces, Ângulos de Euler Pitch/Yaw/Roll, Modo)
"""

from typing import List, Optional
import cv2
import numpy as np

from src.config import COLORS, JarvisColors
from src.engine3d.hologram_renderer import RenderStyle
from src.engine3d.mesh_loader import Mesh3D
from src.vision.gesture_engine import GestureState, GestureTelemetry, HologramTransform
from src.vision.hand_tracker import HandObservation, HandTracker


class JarvisHUD:
    """Camada de interface gráfica em Realidade Aumentada estilo Stark Industries."""

    def __init__(self, colors: JarvisColors = COLORS):
        self.colors = colors

    def draw(
        self,
        frame_bgr: np.ndarray,
        hands: List[HandObservation],
        transform: HologramTransform,
        telemetry: GestureTelemetry,
        mesh: Mesh3D,
        render_style: RenderStyle,
        fps: float,
        status_banner: Optional[str] = None,
    ) -> np.ndarray:
        """Desenha todos os componentes do HUD no frame atual."""
        # 1. Esqueleto e telemetria individual de cada mão detectada
        for hand in hands:
            is_pinching = hand in telemetry.pinching_hands
            self._draw_hand_hud(frame_bgr, hand, is_pinching)

        # 2. Vetores de conexão entre as mãos e o holograma 3D
        self._draw_interaction_links(frame_bgr, transform, telemetry)

        # 3. Painel superior e rodapé de telemetria
        self._draw_telemetry_panels(
            frame_bgr=frame_bgr,
            transform=transform,
            telemetry=telemetry,
            mesh=mesh,
            render_style=render_style,
            fps=fps,
            status_banner=status_banner,
        )

        return frame_bgr

    def _draw_hand_hud(
        self,
        frame_bgr: np.ndarray,
        hand: HandObservation,
        is_pinching: bool,
    ) -> None:
        """Desenha as conexões anatômicas da mão e a mira de pinça entre polegar e indicador."""
        pts = np.round(hand.landmarks_px).astype(np.int32)
        bone_color = self.colors.ORANGE_ALERT if is_pinching else self.colors.CYAN_DARK
        joint_color = self.colors.GOLD_ACCENT if is_pinching else self.colors.CYAN_PRIMARY

        # Ossos / conexões
        for i, j in HandTracker.HAND_CONNECTIONS:
            p1 = (int(pts[i, 0]), int(pts[i, 1]))
            p2 = (int(pts[j, 0]), int(pts[j, 1]))
            cv2.line(frame_bgr, p1, p2, bone_color, 1, lineType=cv2.LINE_AA)

        # Articulações
        for idx, (x, y) in enumerate(pts):
            r = 4 if idx in (4, 8) else 2
            cv2.circle(frame_bgr, (int(x), int(y)), r, joint_color, -1, lineType=cv2.LINE_AA)

        # Anéis cibernéticos no Polegar (4) e Indicador (8)
        thumb_pt = (int(pts[4, 0]), int(pts[4, 1]))
        index_pt = (int(pts[8, 0]), int(pts[8, 1]))
        pinch_pt = (int(hand.pinch_center_px[0]), int(hand.pinch_center_px[1]))

        ring_color = self.colors.ORANGE_ALERT if is_pinching else self.colors.CYAN_PRIMARY
        cv2.circle(frame_bgr, thumb_pt, 10, ring_color, 1, lineType=cv2.LINE_AA)
        cv2.circle(frame_bgr, index_pt, 10, ring_color, 1, lineType=cv2.LINE_AA)
        cv2.line(frame_bgr, thumb_pt, index_pt, ring_color, 2 if is_pinching else 1, lineType=cv2.LINE_AA)

        # Mira no ponto médio da pinça
        cv2.circle(frame_bgr, pinch_pt, 6 if is_pinching else 3, ring_color, -1, lineType=cv2.LINE_AA)
        if is_pinching:
            cv2.circle(frame_bgr, pinch_pt, 16, self.colors.GOLD_ACCENT, 1, lineType=cv2.LINE_AA)

        # Rótulo na palma da mão
        palm_pt = (int(hand.palm_center_px[0]), int(hand.palm_center_px[1]))
        cv2.circle(frame_bgr, palm_pt, 5, self.colors.CYAN_PRIMARY, 1, lineType=cv2.LINE_AA)
        tag = f"{hand.label.upper()} [{'LOCK' if is_pinching else f'{hand.pinch_ratio:.2f}'}]"
        cv2.putText(
            frame_bgr,
            tag,
            (palm_pt[0] - 35, palm_pt[1] + 28),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.42,
            ring_color,
            1,
            cv2.LINE_AA,
        )

    def _draw_interaction_links(
        self,
        frame_bgr: np.ndarray,
        transform: HologramTransform,
        telemetry: GestureTelemetry,
    ) -> None:
        """Desenha linhas de força entre a(s) mão(s) em pinça e o objeto 3D."""
        obj_pt = (int(transform.position_px[0]), int(transform.position_px[1]))

        if telemetry.state == GestureState.DUAL_ZOOM_SCALE and len(telemetry.pinching_hands) >= 2:
            h1, h2 = telemetry.pinching_hands[:2]
            p1 = (int(h1.pinch_center_px[0]), int(h1.pinch_center_px[1]))
            p2 = (int(h2.pinch_center_px[0]), int(h2.pinch_center_px[1]))
            mid = ((p1[0] + p2[0]) // 2, (p1[1] + p2[1]) // 2)

            # Linha de tração de escala entre as duas mãos
            cv2.line(frame_bgr, p1, p2, self.colors.GOLD_ACCENT, 2, lineType=cv2.LINE_AA)
            cv2.circle(frame_bgr, mid, 6, self.colors.WHITE_CORE, -1, lineType=cv2.LINE_AA)
            cv2.circle(frame_bgr, mid, 22, self.colors.GOLD_ACCENT, 1, lineType=cv2.LINE_AA)

            scale_txt = f"ZOOM SCALE: {transform.scale:.2f}x"
            cv2.putText(
                frame_bgr,
                scale_txt,
                (mid[0] - 68, mid[1] - 28),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.52,
                self.colors.GOLD_ACCENT,
                2,
                cv2.LINE_AA,
            )

        elif len(telemetry.pinching_hands) == 1:
            h = telemetry.pinching_hands[0]
            p1 = (int(h.pinch_center_px[0]), int(h.pinch_center_px[1]))
            link_color = (
                self.colors.ORANGE_ALERT
                if telemetry.state == GestureState.SINGLE_MOVE_3D
                else self.colors.CYAN_PRIMARY
            )
            cv2.line(frame_bgr, p1, obj_pt, link_color, 1, lineType=cv2.LINE_AA)

    def _draw_telemetry_panels(
        self,
        frame_bgr: np.ndarray,
        transform: HologramTransform,
        telemetry: GestureTelemetry,
        mesh: Mesh3D,
        render_style: RenderStyle,
        fps: float,
        status_banner: Optional[str] = None,
    ) -> None:
        """Desenha o cabeçalho e rodapé estilo Stark OS."""
        h, w = frame_bgr.shape[:2]

        # Fundo translúcido do topo
        overlay = frame_bgr.copy()
        cv2.rectangle(overlay, (14, 12), (w - 14, 78), self.colors.HUD_BG, -1)
        cv2.rectangle(overlay, (14, h - 46), (w - 14, h - 12), self.colors.HUD_BG, -1)
        cv2.addWeighted(overlay, 0.68, frame_bgr, 0.32, 0, dst=frame_bgr)

        # Bordas ciano
        cv2.rectangle(frame_bgr, (14, 12), (w - 14, 78), self.colors.CYAN_DARK, 1)
        cv2.rectangle(frame_bgr, (14, h - 46), (w - 14, h - 12), self.colors.CYAN_DARK, 1)

        # Linha 1: Título + Modelo 3D + FPS
        rx_deg, ry_deg, rz_deg = np.degrees(transform.rotation_rad)
        header_left = (
            f"J.A.R.V.I.S. 3D HOLOMATRIX  |  MODEL: {mesh.name.upper()} "
            f"({mesh.num_vertices}V / {mesh.num_faces}F)"
        )
        cv2.putText(
            frame_bgr,
            header_left,
            (28, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            self.colors.CYAN_PRIMARY,
            1,
            cv2.LINE_AA,
        )

        fps_color = self.colors.CYAN_PRIMARY if fps >= 24.0 else self.colors.ORANGE_ALERT
        cv2.putText(
            frame_bgr,
            f"FPS: {fps:4.1f}  |  HANDS: {telemetry.active_hands}",
            (w - 245, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            fps_color,
            1,
            cv2.LINE_AA,
        )

        # Linha 2: Estado Gestual + Ângulos Eulerianos + Escala
        state_color = (
            self.colors.GOLD_ACCENT
            if telemetry.state == GestureState.DUAL_ZOOM_SCALE
            else (
                self.colors.ORANGE_ALERT
                if telemetry.state != GestureState.IDLE
                else self.colors.WHITE_CORE
            )
        )
        sub_line = (
            f"STATE: {telemetry.state.value}  |  1H-MODE: {telemetry.mode.value}  |  "
            f"PITCH(X): {rx_deg:+6.1f}d  YAW(Y): {ry_deg:+6.1f}d  ROLL(Z): {rz_deg:+6.1f}d  |  "
            f"SCALE: {transform.scale:.2f}x  |  VIEW: {render_style.value}"
        )
        cv2.putText(
            frame_bgr,
            sub_line,
            (28, 64),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.44,
            state_color,
            1,
            cv2.LINE_AA,
        )

        # Banner de status temporário (ex: "Gerando Modelo 3D com IA...")
        if status_banner:
            cv2.putText(
                frame_bgr,
                f">> {status_banner}",
                (28, 108),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.58,
                self.colors.GOLD_ACCENT,
                2,
                cv2.LINE_AA,
            )

        # Rodapé: Atalhos de Teclado
        footer = (
            "[1-3] Modelos Stark  |  [G] Gerar 3D c/ IA (Prompt)  |  [I] Foto 2D->3D  |  "
            "[M] Modo 1-Mao  |  [V] Estilo Visual  |  [E] Explodir Pecas  |  [R] Reset  |  [Q] Sair"
        )
        cv2.putText(
            frame_bgr,
            footer,
            (26, h - 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.42,
            self.colors.WHITE_CORE,
            1,
            cv2.LINE_AA,
        )
