"""
Fundamentos Matemáticos do Motor 3D (Álgebra Linear & Projeção Perspectiva).

Este módulo implementa do zero, de forma 100% vetorizada em NumPy (sem depender de GPU):
  1. Matrizes de Rotação 3D (Euler Rx, Ry, Rz):
     R = Rz(roll) @ Ry(yaw) @ Rx(pitch)
  2. Projeção Perspectiva (Câmera Pinhole):
     Converte coordenadas 3D (X, Y, Z) no espaço da câmera para pixels 2D (u, v).
  3. Cálculo Vetorizado de Normais, Iluminação Lambertiana/Holográfica e Z-Sorting
     (Algoritmo do Pintor) para renderização correta de profundidade.
"""

import math
import numpy as np


def rotation_matrix_euler(rx: float, ry: float, rz: float) -> np.ndarray:
    """
    Constrói a matriz de rotação 3x3 combinada R = Rz(rz) @ Ry(ry) @ Rx(rx).

    Parâmetros:
        rx: Pitch (rotação em torno do eixo X, em radianos)
        ry: Yaw   (rotação em torno do eixo Y, em radianos)
        rz: Roll  (rotação em torno do eixo Z, em radianos)
    """
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)

    rot_x = np.array([
        [1.0, 0.0, 0.0],
        [0.0,  cx, -sx],
        [0.0,  sx,  cx],
    ], dtype=np.float64)

    rot_y = np.array([
        [ cy, 0.0,  sy],
        [0.0, 1.0, 0.0],
        [-sy, 0.0,  cy],
    ], dtype=np.float64)

    rot_z = np.array([
        [ cz, -sz, 0.0],
        [ sz,  cz, 0.0],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)

    return rot_z @ rot_y @ rot_x


def transform_and_project_vertices(
    vertices: np.ndarray,
    rotation_rad: np.ndarray,
    scale: float,
    center_xy: np.ndarray,
    camera_distance: float = 4.2,
    base_radius_px: float = 165.0,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Rotaciona, escala e projeta um conjunto de vértices 3D (N, 3) para a tela 2D (N, 2).

    Retorna:
        points_2d: Array (N, 2) com coordenadas em pixels (x, y)
        rotated_3d: Array (N, 3) com coordenadas 3D após rotação
    """
    rot_mat = rotation_matrix_euler(
        float(rotation_rad[0]),
        float(rotation_rad[1]),
        float(rotation_rad[2]),
    )

    # Rotação vetorizada: V_rot = V @ R^T
    rotated_3d = vertices @ rot_mat.T

    # Projeção perspectiva pinhole:
    # Quanto menor (camera_distance - Z), maior o objeto aparenta (perspectiva real)
    z_depth = camera_distance - rotated_3d[:, 2]
    z_depth = np.maximum(z_depth, 0.4)  # Evita divisão por zero atrás da câmera

    perspective_factor = (base_radius_px * scale * camera_distance) / z_depth

    points_2d = np.empty((vertices.shape[0], 2), dtype=np.float64)
    points_2d[:, 0] = center_xy[0] + rotated_3d[:, 0] * perspective_factor
    # Eixo Y da imagem cresce para baixo, enquanto Y 3D cresce para cima
    points_2d[:, 1] = center_xy[1] - rotated_3d[:, 1] * perspective_factor

    return points_2d, rotated_3d


def compute_faces_lighting_and_order(
    rotated_vertices: np.ndarray,
    faces: np.ndarray,
    light_dir: np.ndarray = np.array([0.35, 0.65, 0.67], dtype=np.float64),
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Calcula normais das faces triangulares, intensidade de iluminação e ordem Z (Painter's Algorithm).

    Retorna:
        sorted_indices: Índices das faces ordenadas de trás para frente (menor Z -> maior Z)
        intensities: Intensidade luminosa [0.15 .. 1.0] de cada face (na ordem original)
        face_normals: Vetores normais unitários (M, 3) de cada face
    """
    if len(faces) == 0:
        return (
            np.empty(0, dtype=np.int64),
            np.empty(0, dtype=np.float64),
            np.empty((0, 3), dtype=np.float64),
        )

    v0 = rotated_vertices[faces[:, 0]]
    v1 = rotated_vertices[faces[:, 1]]
    v2 = rotated_vertices[faces[:, 2]]

    # Produto vetorial das arestas do triângulo: n = (v1 - v0) x (v2 - v0)
    edge1 = v1 - v0
    edge2 = v2 - v0
    normals = np.cross(edge1, edge2)
    norms = np.linalg.norm(normals, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-8)
    unit_normals = normals / norms

    # Direção da luz normalizada
    light = light_dir / max(float(np.linalg.norm(light_dir)), 1e-8)

    # Em um holograma translúcido, iluminamos ambos os lados (abs do produto escalar)
    # combinando iluminação difusa Lambertiana + brilho de borda (Fresnel/Rim effect)
    lambert = np.abs(unit_normals @ light)
    rim = 1.0 - np.abs(unit_normals[:, 2])  # Faces laterais brilham mais no holograma
    intensities = np.clip(0.25 + 0.50 * lambert + 0.25 * rim, 0.15, 1.0)

    # Profundidade média Z de cada triângulo para ordenação (Algoritmo do Pintor)
    mean_z = (v0[:, 2] + v1[:, 2] + v2[:, 2]) / 3.0
    sorted_indices = np.argsort(mean_z)

    return sorted_indices, intensities, unit_normals
