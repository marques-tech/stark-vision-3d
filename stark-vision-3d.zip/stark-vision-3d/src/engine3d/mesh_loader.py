"""
Carregador e Otimizador Universal de Malhas 3D (.obj, .glb, .gltf, .stl, .ply).

Garante que qualquer modelo 3D (gerado por IA ou baixado da internet):
  1. Seja centralizado na origem (0, 0, 0) e normalizado na esfera unitária (raio = 1.0).
  2. Tenha polígonos triangulados automaticamente.
  3. Seja simplificado (decimado) caso ultrapasse `max_faces` para manter 30-60+ FPS na CPU.
  4. Pré-calcule a lista de arestas únicas (E, 2) para renderização wireframe instantânea.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Union
import numpy as np


@dataclass
class Mesh3D:
    """Estrutura de dados otimizada em NumPy para renderização holográfica em tempo real."""

    name: str
    vertices: np.ndarray  # Shape (N, 3) float64 normalizado em [-1, 1]
    faces: np.ndarray     # Shape (M, 3) int32 (índices de triângulos)
    edges: np.ndarray     # Shape (E, 2) int32 (arestas únicas para wireframe rápido)

    @property
    def num_vertices(self) -> int:
        return int(self.vertices.shape[0])

    @property
    def num_faces(self) -> int:
        return int(self.faces.shape[0])

    @property
    def num_edges(self) -> int:
        return int(self.edges.shape[0])


def extract_unique_edges(faces: np.ndarray) -> np.ndarray:
    """
    Extrai todas as arestas únicas (v_i, v_j) a partir de uma matriz de triângulos (M, 3).
    Isso evita desenhar a mesma aresta duas vezes, dobrando a performance do wireframe na CPU.
    """
    if len(faces) == 0:
        return np.empty((0, 2), dtype=np.int32)

    e1 = faces[:, [0, 1]]
    e2 = faces[:, [1, 2]]
    e3 = faces[:, [2, 0]]
    all_edges = np.vstack((e1, e2, e3))
    sorted_edges = np.sort(all_edges, axis=1)
    unique_edges = np.unique(sorted_edges, axis=0)
    return unique_edges.astype(np.int32)


def normalize_vertices(vertices: np.ndarray) -> np.ndarray:
    """
    Centraliza a malha no centroide da bounding box e escala para raio máximo = 1.0.
    """
    v = np.asarray(vertices, dtype=np.float64)
    if len(v) == 0:
        return v

    min_pt = np.min(v, axis=0)
    max_pt = np.max(v, axis=0)
    center = 0.5 * (min_pt + max_pt)
    centered = v - center

    max_radius = float(np.max(np.linalg.norm(centered, axis=1)))
    if max_radius > 1e-8:
        centered = centered / max_radius
    return centered


def build_mesh(
    name: str,
    vertices: np.ndarray,
    faces: np.ndarray,
    max_faces: int = 1800,
) -> Mesh3D:
    """
    Normaliza vértices, aplica controle de orçamento de polígonos para CPU e extrai arestas.
    """
    norm_v = normalize_vertices(vertices)
    f = np.asarray(faces, dtype=np.int32)

    # Decimação uniforme rápida caso o modelo 3D tenha muitos polígonos para a CPU
    if len(f) > max_faces and max_faces > 0:
        indices = np.linspace(0, len(f) - 1, max_faces, dtype=np.int32)
        f = f[indices]

    edges = extract_unique_edges(f)
    return Mesh3D(name=name, vertices=norm_v, faces=f, edges=edges)


def parse_obj_native(filepath: Union[str, Path], max_faces: int = 1800) -> Mesh3D:
    """
    Parser nativo ultra-rápido para arquivos Wavefront .OBJ.
    Converte faces de N lados (quads, n-gons) em triângulos (fan triangulation).
    """
    path = Path(filepath)
    vertices: List[List[float]] = []
    faces: List[List[int]] = []

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("v "):
                parts = line.split()
                if len(parts) >= 4:
                    vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
            elif line.startswith("f "):
                parts = line.split()[1:]
                face_idxs: List[int] = []
                num_v = len(vertices)
                for p in parts:
                    v_str = p.split("/")[0]
                    if not v_str:
                        continue
                    idx = int(v_str)
                    # Suporte a índices negativos ou 1-indexed do padrão OBJ
                    idx = (idx - 1) if idx > 0 else (num_v + idx)
                    face_idxs.append(idx)
                # Fan triangulation para quads ou polígonos maiores
                for i in range(1, len(face_idxs) - 1):
                    faces.append([face_idxs[0], face_idxs[i], face_idxs[i + 1]])

    if not vertices:
        raise ValueError(f"Nenhum vértice encontrado no arquivo OBJ: {path}")

    v_arr = np.array(vertices, dtype=np.float64)
    f_arr = np.array(faces, dtype=np.int32) if faces else np.empty((0, 3), dtype=np.int32)
    return build_mesh(name=path.stem, vertices=v_arr, faces=f_arr, max_faces=max_faces)


def load_mesh_file(filepath: Union[str, Path], max_faces: int = 1800) -> Mesh3D:
    """
    Carrega arquivos .obj, .glb, .gltf, .stl ou .ply.
    Usa o parser nativo para .obj e `trimesh` para formatos binários como .glb/.stl.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Arquivo 3D não encontrado: {path}")

    ext = path.suffix.lower()
    if ext == ".obj":
        return parse_obj_native(path, max_faces=max_faces)

    try:
        import trimesh

        loaded = trimesh.load(str(path), force="mesh")
        if isinstance(loaded, trimesh.Scene):
            geometries = list(loaded.geometry.values())
            if not geometries:
                raise ValueError(f"Cena 3D vazia em {path}")
            mesh = trimesh.util.concatenate(geometries)
        else:
            mesh = loaded

        v_arr = np.asarray(mesh.vertices, dtype=np.float64)
        f_arr = np.asarray(mesh.faces, dtype=np.int32)
        return build_mesh(name=path.stem, vertices=v_arr, faces=f_arr, max_faces=max_faces)
    except ImportError as exc:
        raise RuntimeError(
            f"Para carregar arquivos '{ext}', instale a biblioteca trimesh: pip install trimesh"
        ) from exc
