"""
Renderizador Holográfico 3D Estilo J.A.R.V.I.S. (Realidade Aumentada sobre Webcam).

Desenha malhas 3D diretamente sobre o frame BGR do OpenCV usando:
  - Z-Sorting (Algoritmo do Pintor) + Iluminação Holográfica Fresnel/Lambert
  - Modo Explodido (Disassemble View estilo Tony Stark: separa as faces ao longo das normais)
  - Três estilos visuais: Holograma Sólido Translúcido, Wireframe Neon e Nuvem de Pontos 3D
"""

from enum import Enum
import cv2
import numpy as np

from src.config import COLORS, RENDER_CFG, JarvisColors, RenderConfig
from src.engine3d.math3d import (
    compute_faces_lighting_and_order,
    rotation_matrix_euler,
    transform_and_project_vertices,
)
from src.engine3d.mesh_loader import Mesh3D
from src.vision.gesture_engine import GestureState, HologramTransform


class RenderStyle(str, Enum):
    """Estilos visuais do holograma 3D."""

    HOLOGRAM_SHADED = "HOLOGRAM_SHADED"   # Faces translúcidas iluminadas + wireframe ciano
    WIREFRAME_NEON = "WIREFRAME_NEON"     # Apenas malha de arestas de alta velocidade
    POINT_CLOUD = "POINT_CLOUD"           # Nuvem de nós energéticos 3D


class HologramRenderer:
    """
    Motor de renderização 3D em software (NumPy + OpenCV) projetado para rodar a 30-60+ FPS na CPU.
    """

    def __init__(
        self,
        config: RenderConfig = RENDER_CFG,
        colors: JarvisColors = COLORS,
    ):
        self.config = config
        self.colors = colors
        self.style = RenderStyle.HOLOGRAM_SHADED
        self.explode_factor: float = 0.0  # 0.0 = montado, >0.0 = visão explodida (Tony Stark)
        self._explode_target: float = 0.0

    def cycle_style(self) -> RenderStyle:
        styles = list(RenderStyle)
        self.style = styles[(styles.index(self.style) + 1) % len(styles)]
        return self.style

    def toggle_explode_view(self) -> bool:
        """Ativa/desativa a animação de visão explodida das peças do modelo 3D."""
        if self._explode_target > 0.01:
            self._explode_target = 0.0
            return False
        self._explode_target = 0.38
        return True

    def render(
        self,
        frame_bgr: np.ndarray,
        mesh: Mesh3D,
        transform: HologramTransform,
        gesture_state: GestureState = GestureState.IDLE,
    ) -> np.ndarray:
        """
        Renderiza o modelo 3D holográfico sobre o frame da webcam.
        """
        # Atualiza interpolação suave do modo explodido
        self.explode_factor += 0.18 * (self._explode_target - self.explode_factor)

        # Escolhe cor temática de acordo com o estado do gesto
        if gesture_state == GestureState.DUAL_ZOOM_SCALE:
            primary_color = self.colors.GOLD_ACCENT
            base_bgr = np.array([40, 190, 255], dtype=np.float64)
        elif gesture_state in (
            GestureState.SINGLE_ROTATE_3D,
            GestureState.SINGLE_MOVE_3D,
            GestureState.SINGLE_COUPLED,
        ):
            primary_color = self.colors.CYAN_PRIMARY
            base_bgr = np.array([255, 225, 30], dtype=np.float64)
        else:
            primary_color = self.colors.CYAN_GLOW
            base_bgr = np.array([255, 185, 0], dtype=np.float64)

        # 1. Projeta vértices para 2D e obtém coordenadas 3D rotacionadas
        pts_2d, rot_3d = transform_and_project_vertices(
            vertices=mesh.vertices,
            rotation_rad=transform.rotation_rad,
            scale=transform.scale,
            center_xy=transform.position_px,
            camera_distance=self.config.camera_distance,
            base_radius_px=self.config.base_model_radius,
        )

        # 2. Desenha anel orbital de base do holograma
        self._draw_orbital_ring(frame_bgr, transform, primary_color, gesture_state)

        # 3. Renderiza conforme o estilo selecionado
        if self.style == RenderStyle.POINT_CLOUD or mesh.num_faces == 0:
            self._render_point_cloud(frame_bgr, pts_2d, rot_3d, primary_color)
        elif self.style == RenderStyle.WIREFRAME_NEON and self.explode_factor < 0.01:
            self._render_wireframe_fast(frame_bgr, pts_2d, mesh.edges, primary_color)
        else:
            self._render_shaded_hologram(
                frame_bgr=frame_bgr,
                mesh=mesh,
                pts_2d=pts_2d,
                rot_3d=rot_3d,
                transform=transform,
                base_bgr=base_bgr,
                wire_color=primary_color,
            )

        # 4. Eixos cartesianos 3D no centro do modelo
        if self.config.show_axes:
            self._draw_local_axes(frame_bgr, transform)

        return frame_bgr

    def _render_shaded_hologram(
        self,
        frame_bgr: np.ndarray,
        mesh: Mesh3D,
        pts_2d: np.ndarray,
        rot_3d: np.ndarray,
        transform: HologramTransform,
        base_bgr: np.ndarray,
        wire_color: tuple[int, int, int],
    ) -> None:
        """Renderiza faces translúcidas ordenadas por profundidade + arestas brilhantes."""
        sorted_idx, intensities, unit_normals = compute_faces_lighting_and_order(
            rotated_vertices=rot_3d,
            faces=mesh.faces,
        )

        overlay = frame_bgr.copy()
        pts_int = np.round(pts_2d).astype(np.int32)

        # Se o modo explodido estiver ativo, deslocamos cada face na direção de sua normal 2D
        explode_px = self.explode_factor * self.config.base_model_radius * transform.scale

        exploded_polys = []
        for idx in sorted_idx:
            face = mesh.faces[idx]
            tri = pts_int[face].copy()

            if explode_px > 0.5:
                n = unit_normals[idx]
                shift = np.array([n[0] * explode_px, -n[1] * explode_px], dtype=np.int32)
                tri = tri + shift
                exploded_polys.append(tri.reshape(-1, 1, 2))

            lum = float(intensities[idx])
            face_color = (
                int(min(255, base_bgr[0] * lum)),
                int(min(255, base_bgr[1] * lum)),
                int(min(255, base_bgr[2] * lum)),
            )
            cv2.fillConvexPoly(overlay, tri, face_color, lineType=cv2.LINE_AA)

        # Mistura translúcida (efeito holograma luminoso)
        cv2.addWeighted(
            overlay,
            self.config.face_alpha,
            frame_bgr,
            1.0 - self.config.face_alpha,
            0,
            dst=frame_bgr,
        )

        # Desenha as arestas wireframe por cima
        if explode_px > 0.5 and exploded_polys:
            cv2.polylines(
                frame_bgr,
                exploded_polys,
                isClosed=True,
                color=wire_color,
                thickness=self.config.wireframe_thickness,
                lineType=cv2.LINE_AA,
            )
        else:
            self._render_wireframe_fast(frame_bgr, pts_2d, mesh.edges, wire_color)

    def _render_wireframe_fast(
        self,
        frame_bgr: np.ndarray,
        pts_2d: np.ndarray,
        edges: np.ndarray,
        color: tuple[int, int, int],
    ) -> None:
        """Renderização vetorizada de todas as arestas com uma única chamada cv2.polylines."""
        if len(edges) == 0:
            return
        pts_int = np.round(pts_2d).astype(np.int32)
        segments = pts_int[edges].reshape(-1, 2, 1, 2)
        cv2.polylines(
            frame_bgr,
            list(segments),
            isClosed=False,
            color=color,
            thickness=self.config.wireframe_thickness,
            lineType=cv2.LINE_AA,
        )

    def _render_point_cloud(
        self,
        frame_bgr: np.ndarray,
        pts_2d: np.ndarray,
        rot_3d: np.ndarray,
        color: tuple[int, int, int],
    ) -> None:
        """Renderiza os vértices 3D como nós de energia com tamanho variável pela profundidade Z."""
        pts_int = np.round(pts_2d).astype(np.int32)
        h, w = frame_bgr.shape[:2]
        z_vals = rot_3d[:, 2]

        for (x, y), z in zip(pts_int, z_vals):
            if 0 <= x < w and 0 <= y < h:
                radius = 2 if z < 0 else 3
                cv2.circle(frame_bgr, (int(x), int(y)), radius, color, -1, lineType=cv2.LINE_AA)
                if z > 0.25:
                    cv2.circle(
                        frame_bgr,
                        (int(x), int(y)),
                        1,
                        self.colors.WHITE_CORE,
                        -1,
                        lineType=cv2.LINE_AA,
                    )

    def _draw_orbital_ring(
        self,
        frame_bgr: np.ndarray,
        transform: HologramTransform,
        color: tuple[int, int, int],
        gesture_state: GestureState,
    ) -> None:
        """Desenha os anéis de mira holográfica ao redor do centro do objeto 3D."""
        cx, cy = int(transform.position_px[0]), int(transform.position_px[1])
        core_r = int(78 * np.clip(transform.scale, 0.65, 1.8))
        outer_r = int(self.config.base_model_radius * transform.scale * 1.12)

        # Anel de núcleo (indica a zona de agarrar/mover no modo SMART_ZONES)
        core_color = (
            self.colors.ORANGE_ALERT
            if gesture_state == GestureState.SINGLE_MOVE_3D
            else self.colors.CYAN_DARK
        )
        cv2.circle(frame_bgr, (cx, cy), core_r, core_color, 1, lineType=cv2.LINE_AA)
        cv2.circle(frame_bgr, (cx, cy), 4, self.colors.WHITE_CORE, -1, lineType=cv2.LINE_AA)

        # Arcos segmentados externos estilo mira J.A.R.V.I.S.
        deg_offset = int(np.degrees(transform.rotation_rad[2])) % 360
        for base_angle in (0, 90, 180, 270):
            start_a = base_angle + deg_offset + 12
            end_a = base_angle + deg_offset + 78
            cv2.ellipse(
                frame_bgr,
                (cx, cy),
                (outer_r, outer_r),
                0,
                start_a,
                end_a,
                color,
                1,
                lineType=cv2.LINE_AA,
            )

    def _draw_local_axes(
        self,
        frame_bgr: np.ndarray,
        transform: HologramTransform,
    ) -> None:
        """Desenha a tríade de eixos 3D (X, Y, Z) rotacionados no centro do holograma."""
        axis_pts = np.array([
            [0.0, 0.0, 0.0],
            [0.45, 0.0, 0.0],  # Eixo X
            [0.0, 0.45, 0.0],  # Eixo Y
            [0.0, 0.0, 0.45],  # Eixo Z
        ], dtype=np.float64)

        pts_2d, _ = transform_and_project_vertices(
            vertices=axis_pts,
            rotation_rad=transform.rotation_rad,
            scale=transform.scale,
            center_xy=transform.position_px,
            camera_distance=self.config.camera_distance,
            base_radius_px=self.config.base_model_radius,
        )
        p0 = tuple(np.round(pts_2d[0]).astype(np.int32))
        px = tuple(np.round(pts_2d[1]).astype(np.int32))
        py = tuple(np.round(pts_2d[2]).astype(np.int32))
        pz = tuple(np.round(pts_2d[3]).astype(np.int32))

        cv2.line(frame_bgr, p0, px, (80, 80, 255), 2, lineType=cv2.LINE_AA)   # X: Vermelho
        cv2.line(frame_bgr, p0, py, (80, 255, 80), 2, lineType=cv2.LINE_AA)   # Y: Verde
        cv2.line(frame_bgr, p0, pz, (255, 200, 50), 2, lineType=cv2.LINE_AA)  # Z: Azul/Ciano
