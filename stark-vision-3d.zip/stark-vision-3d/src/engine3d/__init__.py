"""Motor Gráfico 3D Vetorial em NumPy/OpenCV otimizado para CPU."""
