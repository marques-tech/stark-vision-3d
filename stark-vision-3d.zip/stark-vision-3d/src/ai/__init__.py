"""Módulo de Inteligência Artificial Generativa 3D e Síntese de Malhas."""
